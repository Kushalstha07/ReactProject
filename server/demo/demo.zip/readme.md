1) Project setup
2) Database connection
3) User crud operation


 dependency
   express, pg, nodemon,sequalize,donenv, body-parser



running script

npm run dev  // for development
npm start   
